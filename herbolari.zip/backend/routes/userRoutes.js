const express = require('express');
const { registerUser, loginUser } = require('../controllers/userControllers')
const router = express.Router();
const axios = require('axios');
const {Storage} = require('@google-cloud/storage');

router.route('/register').post(registerUser);
router.route('/login').post(loginUser);

//Procesamos la imagen que recibimos desde el front end. Aqui se hace la prediccion
router.route('/camera').post(async (req, res) => {
    imagen = req.body.image;
    coordenadas = req.body.coords;
    newCoords = {
        'latitude': coordenadas.lat,
        'longitude': coordenadas.long
    }

    //EJEMPLO DE PETICION A UNA CLOUD FUNCTION
    //COMO SACAR LA AUTHORIZATION? Desde google cloud, ir a la consola y poner este comando: gcloud auth print-identity-token


    let authorization = `eyJhbGciOiJSUzI1NiIsImtpZCI6IjQ4NmYxNjQ4MjAwNWEyY2RhZjI2ZDkyMTQwMThkMDI5Y2E0NmZiNTYiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiYXpwIjoiNjE4MTA0NzA4MDU0LTlyOXMxYzRhbGczNmVybGl1Y2hvOXQ1Mm4zMm42ZGdxLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwiYXVkIjoiNjE4MTA0NzA4MDU0LTlyOXMxYzRhbGczNmVybGl1Y2hvOXQ1Mm4zMm42ZGdxLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwic3ViIjoiMTAzNjI5NDk0Mjc3NTM2OTE2NDg5IiwiZW1haWwiOiJlcmljcHVlcnRvcmVxdWVuYUBnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiYXRfaGFzaCI6IjY1UmJuUHVtbkxER2MyeFRDZWpSNmciLCJpYXQiOjE2NTM2NzU2NjMsImV4cCI6MTY1MzY3OTI2MywianRpIjoiZWQyNmI0YWRiM2I5YTAxYjFlM2VkMGZiM2E1NjAzZTA3ZDIwZTkzNyJ9.QSBk_5EXgdehdEX5xRYAl5ig9rAyEnxT0EQ-HThG_5xe_RUGYdzC8J6JDvkY9tfgvVxZe13Dzyhj5fOT1cyryOMowfKIX8gmrbstQrFarNxfo3M4Lf3TqjQrt0-MAW_Se9wOtdW4HQLpuu_nbmbVc7jE9UACmtbudCjAWgMZBmFkrjRKK_awlKMbRnUQcJUCd5_SVk9-SD-bhXqMjIMqr695FzVfiGm8OA-S3yEfI7A3YtQq6z8A2KfQWXhSXjKDsiXfNyJfwfz4Htsmnu4qUAavdVm2JUmYkjMMgnlyB_un3k6SRPbCAFORyDEEzQH2eorMMRV_Bizh5GHSs1jnug`
    // axios.post(url, data, options)
    // data: { 'key': 'value' } Aqui lo importante
    // options: { headers: { ... } } //Dentro de headers necesitaremos dos objetos: Authorization y Content-Type, en priincipio no necesitamos mas dentro de aqui

    // Recibir arbol mas cercano y sus coordenadas
    const test = await axios.post(`https://us-central1-allergies-349815.cloudfunctions.net/nearestTree`,
        newCoords,
        {
            headers: {
                'Authorization': 'Bearer ' + authorization,
                'Content-Type': 'application/json',
            }
        }
    ).then(val => val.data).catch(err => { console.log(err.message)}); //Dentro de los corchetes {} hacer lo que haga falta con los datos

    /////////////////////////////////////////////////
    // //// PREDICCION DE IMAGEN
    // predictionReq = {
    //     'instances': [{
    //         'content': imagen (string en base64),
    //     }],
    //     'parameters': {
    //         'confidenceTreshold': 0-1,
    //         'maxPredictions': 2
    //     }
    // }
    
    //PARA OBTENER ESTE TOKEN USAR EN GOOGLE CLOUD LA COMANDA gcloud auth print-access-token
    const predictionAuthorization = `Bearer ya29.a0ARrdaM-ZEnSlcVlOza6OcgdpAnyS8XPVgNSHB6Du7xR6CKAcQcDqPKO_vGo0ia9OmPcWOEmG70-O_-zB5nfnRkFvDj_NvxgVuoFFl67xSDzMUnbSG65SmU07Z9ptKX19Dil3_zSp65PdJgFIGPA-lVaLMhIl4zOM90F7zYIjOk78oj9Ja9iGd5trAr7YpOO76ojr76OPb3eMKxas-anqbUJKQ2lwqnjJUhVSJ2viwqSvKouHhy-6pTTMW6tyWW-M5mHTo-I`
    
    let treeName = await axios.post(`https://europe-west4-aiplatform.googleapis.com/v1/projects/allergies-349815/locations/europe-west4/endpoints/4546506969132826624:predict`,
    {
        instances : [{
            content : req.body.image.replace(`data:image/jpeg;base64,`, "")
        }],
        parameters: {
            "confidenceThreshold": 0.5,
            "maxPredictions": 1
        }
    },
    {
        headers: {
            'Authorization': predictionAuthorization,
            'Content-Type': 'application/json'
        }
    })
    .then(response => {
        console.log(response.data.predictions)
        console.log(response.data.predictions[0].confidences)
        //Argmax porque el maxPredictions lo ignora 
        let confidence = response.data.predictions[0].confidences
        maxProbabilityIndex = confidence.indexOf(Math.max(...confidence))
        return response.data.predictions[0].displayNames[maxProbabilityIndex]
    })
    .catch(err => { console.log(err.response.data)});

    if (treeName == undefined) { // Control de si la prediccion obtiene algun resultado segun el threshold o no
        console.log('Treename undefined, mandando ' + test)
        res.status(200).json({closestTree: test})
    } else {
        console.log(treeName)
        treeName = treeName.replace('_', ' ');
        treeName = treeName.charAt(0).toUpperCase() + treeName.slice(1);
        
        res.status(200).json({tree: treeName, closestTree: test})
    }
    

    ////////////////////////////////////////////
    // // AÑADIR A UN BUCKET IMAGENES
    //    Hay que mandar un buffer de la imagen usando pipes
    //     const storage = new Storage();
    //     const bucket = storage.bucket('test_bucket_85632945672984')
            
    //     const blob = bucket.file('name.jpg');
    //     const blobStream = blob.createWriteStream()
    //     let buf = Buffer.from(req.body.image, 'base64');
    //     blobStream.on('finish', () => {
    //         const publicUrl = format(`https://storage.googleapis.com/${bucket.name}/${blob.name}`)
    //     })
    //     blobStream.end(buf);


});

module.exports = router; 