const express = require('express');
const notes = require("./data/notes");
const dotenv = require("dotenv");
const connectDB = require('./config/db');
const userRoutes = require('./routes/userRoutes');
const { notFound, errorHandler } = require('./middlewares/errorMiddleware');
const cors = require('cors');
const bodyParser = require('body-parser');


const app = express();

app.use(bodyParser.urlencoded({extended: true}))
app.use(bodyParser.json())
app.use(cors({
    origin: 'http://localhost:3000'
}));

dotenv.config();
//connectDB(); // Lo comento por ahora pero esto funciona bien
app.use(express.json());

app.get('/', (req, res) => {
    res.send("API is running...");
});

app.get("/api/notes", (req, res) => {
    res.json(notes);
});

app.use('/api/users', userRoutes)
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

app.listen(PORT, console.log(`Server started on Port ${PORT}`));

//app.listen(process.env.PORT,console.log("server started"))