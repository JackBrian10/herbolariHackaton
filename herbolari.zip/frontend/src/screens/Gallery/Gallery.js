import './Gallery.css'
import MainScreen from '../../components/MainScreen/MainScreen';
import React, { useMemo } from "react";
import { GoogleMap, useLoadScript, Marker } from "@react-google-maps/api";
import Template from '../../components/Template/Template';
import axios from 'axios';

const Gallery = () => {
  const { isLoaded } = useLoadScript({
    googleMapsApiKey: "AIzaSyC7sUH5S7cl5Ls-fS2My5IOkPp7_2rR2FI",
  });

  if (!isLoaded) return <div>Loading...</div>;
  return <Map />;
}

async function Map() {
  let latitud = {}

  // await axios.post("http://localhost:5000/api/users/getLatitude")
  //   .then(valor => {
  //     latitud = valor;
  //     console.log(latitud);
  //   })
  // const markerTest = useMemo(() => ({ lat: 41.5000758, lng: 2.1058671 }), []);


  return (
    <MainScreen title="Galería">
      <Template title="Foto 1">
        <GoogleMap zoom={10} center={{ lat: 41.5000758, lng: 2.1058671 }} mapContainerClassName="map-container">
          <Marker
            title={'The marker`s title will appear as a tooltip.'}
            name={'SOMA'}
            key={1}
            //position={markerTest}
          />
        </GoogleMap>
      </Template>
    </MainScreen>
  );
}

export default Gallery