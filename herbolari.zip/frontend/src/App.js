
import './App.css';
import Footer from './components/Footer/Footer';
import Header from './components/Header/Header';
import HeroPage from './screens/HeroPage/HeroPage';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Gallery from './screens/Gallery/Gallery';
import LoginScreen from './screens/LoginScreen/LoginScreen';
import RegisterScreen from './screens/RegisterScreen/RegisterScreen';
import Camera from './screens/Camera/Camera';
import React from 'react';

const App = () => (
  <>
    <Router>
      <Header />
      <main>
        <Routes>
          <Route path='/' element={<HeroPage/>} />
          <Route path='/Camera' element={<Camera/>} />
          <Route path='/login' element={<LoginScreen/>} />
          <Route path='/register' element={<RegisterScreen/>} />
          <Route path="/Gallery" element={<Gallery/>} />
        </Routes>
      </main>
      <Footer />
    </Router>
  </>
);

export default App;
